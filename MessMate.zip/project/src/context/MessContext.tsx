import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Meal {
  id: string;
  date: Date;
  type: 'breakfast' | 'lunch' | 'dinner';
  amount: number;
}

interface MessContextType {
  totalAmount: number;
  meals: Meal[];
  addMeal: (amount: number, type: 'breakfast' | 'lunch' | 'dinner', date?: Date) => void;
  deleteMeal: (id: string) => void;
}

const MessContext = createContext<MessContextType | undefined>(undefined);

export const MessProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [totalAmount, setTotalAmount] = useState(0);
  const [meals, setMeals] = useState<Meal[]>([]);

  const addMeal = (amount: number, type: 'breakfast' | 'lunch' | 'dinner', date?: Date) => {
    const newMeal: Meal = {
      id: Math.random().toString(36).substr(2, 9),
      date: date || new Date(),
      type,
      amount
    };
    setMeals(prev => [...prev, newMeal]);
    setTotalAmount(prev => prev + amount);
  };

  const deleteMeal = (id: string) => {
    const meal = meals.find(m => m.id === id);
    if (meal) {
      setMeals(prev => prev.filter(m => m.id !== id));
      setTotalAmount(prev => prev - meal.amount);
    }
  };

  return (
    <MessContext.Provider value={{ totalAmount, meals, addMeal, deleteMeal }}>
      {children}
    </MessContext.Provider>
  );
};

export const useMessContext = () => {
  const context = useContext(MessContext);
  if (context === undefined) {
    throw new Error('useMessContext must be used within a MessProvider');
  }
  return context;
};