import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyAtn-njth81RjHmmmqSeIH3zbM1uDpXdi4",
  authDomain: "mess-management-3140b.firebaseapp.com",
  projectId: "mess-management-3140b",
  storageBucket: "mess-management-3140b.firebasestorage.app",
  messagingSenderId: "161517941806",
  appId: "1:161517941806:web:3c2723619fa3a85322dbbf",
  measurementId: "G-2B2R1TEE7Y"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const analytics = getAnalytics(app);

export default app;