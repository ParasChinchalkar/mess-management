import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, DollarSign, Calendar, Home, UserPlus, LogOut, User } from 'lucide-react';
import { useMessContext } from '../context/MessContext';
import { useAuth } from '../context/AuthContext';
import { signOut } from 'firebase/auth';
import { auth } from '../lib/firebase';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const { totalAmount } = useMessContext();
  const { user } = useAuth();

  const menuItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Calendar, label: 'Payments & Calendar', path: '/payments' },
  ];

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <nav className="bg-spotify-black border-b border-spotify-dark-gray shadow-xl backdrop-blur-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-xl hover:bg-spotify-dark-gray lg:hidden transition-colors"
            >
              {isOpen ? <X size={24} className="text-white" /> : <Menu size={24} className="text-white" />}
            </button>
            <Link to="/" className="font-bold text-2xl tracking-tight text-white">
              Mess Manager
            </Link>
            
            <div className="hidden lg:flex items-center gap-6 ml-8">
              {menuItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl hover:bg-spotify-dark-gray transition-all duration-200 font-medium text-white"
                >
                  <item.icon size={18} className="text-spotify-green" />
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <Link
              to="/payments"
              className="flex items-center gap-2 bg-spotify-dark-gray px-5 py-2 rounded-xl hover:bg-[#383838] transition-all duration-200"
            >
              <DollarSign size={20} className="text-spotify-green" />
              <span className="font-medium text-white">₹{totalAmount}</span>
            </Link>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="flex items-center gap-2 bg-spotify-dark-gray px-5 py-2 rounded-xl hover:bg-[#383838] transition-all duration-200"
                >
                  <User size={20} className="text-spotify-green" />
                  <span className="font-medium text-white">{user.email?.split('@')[0]}</span>
                </button>

                {isProfileOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-spotify-dark-gray rounded-xl shadow-xl py-1 z-50">
                    <button
                      onClick={handleLogout}
                      className="flex items-center gap-2 px-4 py-3 text-white hover:bg-[#383838] w-full transition-colors"
                    >
                      <LogOut size={18} className="text-spotify-green" />
                      Sign out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/login"
                className="flex items-center gap-2 bg-spotify-dark-gray px-5 py-2 rounded-xl hover:bg-[#383838] transition-all duration-200 font-medium text-white"
              >
                <User size={20} className="text-spotify-green" />
                Sign in
              </Link>
            )}
          </div>
        </div>
      </div>
      
      {isOpen && (
        <div className="lg:hidden border-t border-spotify-dark-gray">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className="flex items-center gap-2 px-4 py-3 rounded-xl hover:bg-spotify-dark-gray transition-all duration-200 text-white"
                onClick={() => setIsOpen(false)}
              >
                <item.icon size={18} className="text-spotify-green" />
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;