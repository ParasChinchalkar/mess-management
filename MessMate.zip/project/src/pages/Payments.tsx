import React, { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths } from 'date-fns';
import { Calendar, IndianRupee, CreditCard, ChevronLeft, ChevronRight, Plus, Trash2, History } from 'lucide-react';
import { useMessContext } from '../context/MessContext';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const MEAL_PRICES = {
  breakfast: 50,
  lunch: 80,
  dinner: 80,
};

const PAYMENT_METHODS = [
  { id: 'upi', name: 'UPI', icon: '📱' },
  { id: 'card', name: 'Card', icon: '💳' },
  { id: 'netbanking', name: 'Net Banking', icon: '🏦' }
];

const Payments = () => {
  const { totalAmount, meals, addMeal, deleteMeal } = useMessContext();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showAddMealModal, setShowAddMealModal] = useState(false);
  const [selectedMealDate, setSelectedMealDate] = useState<Date | null>(null);
  const [showMealList, setShowMealList] = useState(false);
  const [activeMealDate, setActiveMealDate] = useState<Date | null>(null);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('');
  const [paymentStep, setPaymentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  useEffect(() => {
    if (user) {
      fetchPaymentHistory();
    }
  }, [user]);

  const fetchPaymentHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('payments')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      setPaymentHistory(data || []);
    } catch (error) {
      console.error('Error fetching payment history:', error);
    }
  };

  const handlePayment = async () => {
    if (!selectedPaymentMethod || !user) return;

    setLoading(true);
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Record payment in database
      const { error } = await supabase
        .from('payments')
        .insert({
          user_id: user.id,
          amount: totalAmount,
          status: 'completed',
          payment_method: selectedPaymentMethod,
          transaction_id: `TXN${Math.random().toString(36).substr(2, 9).toUpperCase()}`
        });

      if (error) throw error;

      // Reset payment state
      setPaymentStep(3); // Success step
      await fetchPaymentHistory();
    } catch (error) {
      console.error('Payment error:', error);
      setPaymentStep(4); // Error step
    } finally {
      setLoading(false);
    }
  };

  const getMealsForDate = (date: Date) => {
    return meals.filter(meal => isSameDay(new Date(meal.date), date));
  };

  const nextMonth = () => setSelectedDate(current => addMonths(current, 1));
  const prevMonth = () => setSelectedDate(current => subMonths(current, 1));

  const handleAddMeal = (type: 'breakfast' | 'lunch' | 'dinner') => {
    if (selectedMealDate) {
      addMeal(MEAL_PRICES[type], type, selectedMealDate);
      setShowAddMealModal(false);
    }
  };

  const handleDateClick = (date: Date) => {
    setSelectedMealDate(date);
    setShowAddMealModal(true);
  };

  const handleShowMeals = (date: Date) => {
    setActiveMealDate(date);
    setShowMealList(true);
  };

  const resetPaymentModal = () => {
    setShowPaymentModal(false);
    setPaymentStep(1);
    setSelectedPaymentMethod('');
  };

  return (
    <div className="min-h-screen bg-spotify-black text-white py-8 px-4">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-8">
        {/* Calendar View */}
        <div className="bg-spotify-dark-gray rounded-3xl shadow-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold flex items-center text-white">
              <Calendar className="mr-2 text-spotify-green" /> Meal Calendar
            </h2>
            <div className="flex items-center gap-2">
              <button
                onClick={prevMonth}
                className="p-2 hover:bg-[#383838] rounded-lg transition-colors"
                aria-label="Previous month"
              >
                <ChevronLeft size={20} className="text-spotify-green" />
              </button>
              <span className="font-medium min-w-[120px] text-center">
                {format(selectedDate, 'MMMM yyyy')}
              </span>
              <button
                onClick={nextMonth}
                className="p-2 hover:bg-[#383838] rounded-lg transition-colors"
                aria-label="Next month"
              >
                <ChevronRight size={20} className="text-spotify-green" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center font-medium text-spotify-light-gray py-2">
                {day}
              </div>
            ))}
            {daysInMonth.map((date, i) => {
              const dayMeals = getMealsForDate(date);
              const hasBreakfast = dayMeals.some(meal => meal.type === 'breakfast');
              const hasLunch = dayMeals.some(meal => meal.type === 'lunch');
              const hasDinner = dayMeals.some(meal => meal.type === 'dinner');
              const totalForDay = dayMeals.reduce((sum, meal) => sum + meal.amount, 0);

              return (
                <div
                  key={i}
                  className={`p-2 border rounded-lg transition-colors cursor-pointer ${
                    dayMeals.length > 0 
                      ? 'bg-[#383838] border-spotify-green hover:bg-[#404040]' 
                      : 'border-[#383838] hover:border-spotify-green hover:bg-[#2a2a2a]'
                  }`}
                  onClick={() => dayMeals.length > 0 ? handleShowMeals(date) : handleDateClick(date)}
                >
                  <div className="text-center font-medium">{format(date, 'd')}</div>
                  {dayMeals.length > 0 ? (
                    <>
                      <div className="flex justify-center gap-1 mt-1">
                        {hasBreakfast && <div className="w-2 h-2 bg-spotify-green rounded-full" />}
                        {hasLunch && <div className="w-2 h-2 bg-spotify-green rounded-full opacity-70" />}
                        {hasDinner && <div className="w-2 h-2 bg-spotify-green rounded-full opacity-40" />}
                      </div>
                      <div className="text-xs text-center mt-1 text-spotify-light-gray">
                        ₹{totalForDay}
                      </div>
                    </>
                  ) : (
                    <div className="flex justify-center mt-2">
                      <Plus size={16} className="text-spotify-light-gray" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-spotify-green rounded-full" />
              <span className="text-spotify-light-gray">Breakfast (₹{MEAL_PRICES.breakfast})</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-spotify-green rounded-full opacity-70" />
              <span className="text-spotify-light-gray">Lunch (₹{MEAL_PRICES.lunch})</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-spotify-green rounded-full opacity-40" />
              <span className="text-spotify-light-gray">Dinner (₹{MEAL_PRICES.dinner})</span>
            </div>
          </div>
        </div>

        {/* Payment Summary */}
        <div className="space-y-6">
          <div className="bg-spotify-dark-gray rounded-3xl shadow-xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold flex items-center text-white">
                <IndianRupee className="mr-2 text-spotify-green" /> Payment Summary
              </h2>
              <Link
                to="/payment-history"
                className="flex items-center gap-2 px-4 py-2 rounded-xl hover:bg-[#383838] transition-colors text-spotify-green"
              >
                <History size={20} />
                View All
              </Link>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-[#383838] rounded-xl border border-spotify-green/20">
                <div>
                  <span className="font-medium text-white">Total Amount Due</span>
                  <p className="text-sm text-spotify-light-gray">For {format(selectedDate, 'MMMM yyyy')}</p>
                </div>
                <span className="text-2xl font-bold text-spotify-green">₹{totalAmount}</span>
              </div>

              <div className="bg-[#282828] rounded-xl overflow-hidden border border-[#383838]">
                <div className="p-4 bg-[#333333] border-b border-[#383838]">
                  <h3 className="font-medium text-white">Recent Payments</h3>
                </div>
                <div className="divide-y divide-[#383838]">
                  {paymentHistory.map((payment) => (
                    <div key={payment.id} className="flex justify-between items-center p-4 hover:bg-[#333333] transition-colors">
                      <div>
                        <p className="font-medium text-white">₹{payment.amount}</p>
                        <p className="text-sm text-spotify-light-gray">
                          {format(new Date(payment.created_at), 'MMM d, yyyy')}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="capitalize text-spotify-green">{payment.status}</p>
                        <p className="text-sm text-spotify-light-gray capitalize">{payment.payment_method}</p>
                      </div>
                    </div>
                  ))}
                  {paymentHistory.length === 0 && (
                    <div className="p-4 text-center text-spotify-light-gray">
                      No payment history
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={() => setShowPaymentModal(true)}
                className="w-full spotify-button flex items-center justify-center gap-2"
              >
                <CreditCard size={20} />
                Pay Now
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Add Meal Modal */}
      {showAddMealModal && selectedMealDate && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-spotify-dark-gray rounded-3xl p-6 max-w-md w-full border border-[#383838]">
            <h3 className="text-xl font-bold mb-4 text-white">Add Meal Entry</h3>
            <p className="text-spotify-light-gray mb-6">
              {format(selectedMealDate, 'MMMM d, yyyy')}
            </p>
            <div className="space-y-4">
              {(['breakfast', 'lunch', 'dinner'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => handleAddMeal(type)}
                  className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-[#383838] border border-[#383838] transition-colors"
                >
                  <span className="capitalize text-white">{type}</span>
                  <span className="font-medium text-spotify-green">₹{MEAL_PRICES[type]}</span>
                </button>
              ))}
              <button
                onClick={() => setShowAddMealModal(false)}
                className="w-full px-6 py-3 rounded-xl hover:bg-[#383838] border border-[#383838] text-spotify-light-gray transition-colors mt-4"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Meal List Modal */}
      {showMealList && activeMealDate && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-spotify-dark-gray rounded-3xl p-6 max-w-md w-full border border-[#383838]">
            <h3 className="text-xl font-bold mb-4 text-white">Meals for {format(activeMealDate, 'MMMM d, yyyy')}</h3>
            <div className="space-y-4">
              {getMealsForDate(activeMealDate).map((meal) => (
                <div key={meal.id} className="flex items-center justify-between p-4 rounded-xl border border-[#383838] hover:bg-[#383838] transition-colors">
                  <div>
                    <p className="font-medium capitalize text-white">{meal.type}</p>
                    <p className="text-sm text-spotify-light-gray">₹{meal.amount}</p>
                  </div>
                  <button
                    onClick={() => {
                      deleteMeal(meal.id);
                      if (getMealsForDate(activeMealDate).length <= 1) {
                        setShowMealList(false);
                      }
                    }}
                    className="text-spotify-light-gray hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
              <div className="flex gap-4 mt-6">
                <button
                  onClick={() => {
                    setShowMealList(false);
                    handleDateClick(activeMealDate);
                  }}
                  className="flex-1 spotify-button"
                >
                  Add Meal
                </button>
                <button
                  onClick={() => setShowMealList(false)}
                  className="flex-1 px-6 py-3 rounded-xl hover:bg-[#383838] border border-[#383838] text-spotify-light-gray transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-spotify-dark-gray rounded-3xl p-6 max-w-md w-full border border-[#383838]">
            {paymentStep === 1 && (
              <>
                <h3 className="text-xl font-bold mb-6 text-white">Choose Payment Method</h3>
                <div className="space-y-4">
                  {PAYMENT_METHODS.map((method) => (
                    <button
                      key={method.id}
                      onClick={() => {
                        setSelectedPaymentMethod(method.id);
                        setPaymentStep(2);
                      }}
                      className={`w-full flex items-center justify-between p-4 rounded-xl border transition-colors ${
                        selectedPaymentMethod === method.id
                          ? 'border-spotify-green bg-[#383838]'
                          : 'border-[#383838] hover:bg-[#383838]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{method.icon}</span>
                        <span className="font-medium text-white">{method.name}</span>
                      </div>
                    </button>
                  ))}
                  <button
                    onClick={resetPaymentModal}
                    className="w-full px-6 py-3 rounded-xl hover:bg-[#383838] border border-[#383838] text-spotify-light-gray transition-colors mt-4"
                  >
                    Cancel
                  </button>
                </div>
              </>
            )}

            {paymentStep === 2 && (
              <>
                <h3 className="text-xl font-bold mb-6 text-white">Confirm Payment</h3>
                <div className="space-y-6">
                  <div className="bg-[#383838] p-4 rounded-xl border border-spotify-green/20">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-white">Total Amount</span>
                      <span className="font-bold text-xl text-spotify-green">₹{totalAmount}</span>
                    </div>
                    <p className="text-sm text-spotify-light-gray">
                      Payment Method: {PAYMENT_METHODS.find(m => m.id === selectedPaymentMethod)?.name}
                    </p>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setPaymentStep(1)}
                      className="flex-1 px-6 py-3 rounded-xl hover:bg-[#383838] border border-[#383838] text-spotify-light-gray transition-colors"
                    >
                      Back
                    </button>
                    <button
                      onClick={handlePayment}
                      disabled={loading}
                      className="flex-1 spotify-button"
                    >
                      {loading ? 'Processing...' : 'Confirm Payment'}
                    </button>
                  </div>
                </div>
              </>
            )}

            {paymentStep === 3 && (
              <div className="text-center">
                <div className="w-16 h-16 bg-spotify-green rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-3xl">✓</span>
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">Payment Successful!</h3>
                <p className="text-spotify-light-gray mb-6">Your payment has been processed successfully.</p>
                <button
                  onClick={resetPaymentModal}
                  className="spotify-button w-full"
                >
                  Done
                </button>
              </div>
            )}

            {paymentStep === 4 && (
              <div className="text-center">
                <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-3xl">✕</span>
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">Payment Failed</h3>
                <p className="text-spotify-light-gray mb-6">There was an error processing your payment. Please try again.</p>
                <div className="flex gap-3">
                  <button
                    onClick={resetPaymentModal}
                    className="flex-1 px-6 py-3 rounded-xl hover:bg-[#383838] border border-[#383838] text-spotify-light-gray transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => setPaymentStep(1)}
                    className="flex-1 spotify-button"
                  >
                    Try Again
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Payments;