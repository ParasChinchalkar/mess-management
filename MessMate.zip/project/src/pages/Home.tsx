import React, { useState } from 'react';
import { format, addDays, startOfWeek } from 'date-fns';
import { Clock, Utensils, ChevronRight, Sparkles } from 'lucide-react';
import { useMessContext } from '../context/MessContext';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const MESS_TIMINGS = {
  breakfast: { start: '7:30 AM', end: '9:30 AM', price: 50 },
  lunch: { start: '12:30 PM', end: '2:30 PM', price: 80 },
  dinner: { start: '7:30 PM', end: '9:30 PM', price: 80 },
};

const WEEKLY_MENU = {
  Monday: {
    breakfast: 'Idli, Sambar, Chutney',
    lunch: 'Rice, Dal, Roti, Paneer Curry',
    dinner: 'Rice, Dal, Roti, Mixed Veg'
  },
  Tuesday: {
    breakfast: 'Poha, Boiled Eggs',
    lunch: 'Rice, Dal, Roti, Chicken Curry',
    dinner: 'Rice, Dal, Roti, Aloo Gobi'
  },
  Wednesday: {
    breakfast: 'Upma, Bread Toast',
    lunch: 'Rice, Dal, Roti, Fish Curry',
    dinner: 'Rice, Dal, Roti, Dal Makhani'
  },
  Thursday: {
    breakfast: 'Dosa, Sambar',
    lunch: 'Rice, Dal, Roti, Rajma',
    dinner: 'Rice, Dal, Roti, Egg Curry'
  },
  Friday: {
    breakfast: 'Puri, Bhaji',
    lunch: 'Rice, Dal, Roti, Chole',
    dinner: 'Rice, Dal, Roti, Mushroom'
  },
  Saturday: {
    breakfast: 'Paratha, Curd',
    lunch: 'Rice, Dal, Roti, Mutton Curry',
    dinner: 'Rice, Dal, Roti, Palak Paneer'
  },
  Sunday: {
    breakfast: 'Vada, Sambar',
    lunch: 'Biryani, Raita',
    dinner: 'Rice, Dal, Roti, Chicken Curry'
  }
};

const Home = () => {
  const [selectedDate] = useState(new Date());
  const { addMeal } = useMessContext();
  const { user } = useAuth();
  
  const startOfCurrentWeek = startOfWeek(selectedDate);
  const weekDays = [...Array(7)].map((_, i) => addDays(startOfCurrentWeek, i));

  return (
    <div className="min-h-screen bg-spotify-black">
      {!user ? (
        <div className="max-w-7xl mx-auto px-4 py-24 text-center">
          <div className="inline-flex items-center justify-center p-1 mb-8 bg-spotify-dark-gray rounded-full">
            <Sparkles className="text-spotify-green animate-pulse" size={24} />
          </div>
          <h1 className="text-5xl font-bold text-white mb-6">
            Welcome to Mess Manager
          </h1>
          <p className="text-xl text-spotify-light-gray mb-12 max-w-2xl mx-auto">
            Your all-in-one solution for managing mess schedules and payments. Join us for a seamless dining experience.
          </p>
          <div className="flex justify-center gap-6">
            <Link
              to="/login"
              className="spotify-button"
            >
              Get Started
            </Link>
            <Link
              to="/register"
              className="bg-transparent text-spotify-green px-8 py-4 rounded-full text-lg font-medium hover:bg-spotify-dark-gray transition-all duration-200 border-2 border-spotify-green transform hover:scale-105"
            >
              Register Now
            </Link>
          </div>
        </div>
      ) : (
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Weekly Menu */}
            <div className="bg-spotify-dark-gray rounded-3xl shadow-xl p-8">
              <h2 className="text-3xl font-bold mb-8 flex items-center text-white">
                <Utensils className="mr-3 text-spotify-green" /> Weekly Menu
              </h2>
              <div className="space-y-6">
                {weekDays.map((date, index) => (
                  <div key={index} className="border-b border-[#383838] pb-4 last:border-b-0 group hover:bg-[#383838] p-4 rounded-2xl transition-all duration-300">
                    <h3 className="font-semibold text-xl mb-3 text-spotify-green">
                      {format(date, 'EEEE')}
                    </h3>
                    <div className="space-y-3">
                      {Object.entries(WEEKLY_MENU[format(date, 'EEEE') as keyof typeof WEEKLY_MENU]).map(([meal, items]) => (
                        <p key={meal} className="flex items-center text-white group-hover:text-white">
                          <ChevronRight size={18} className="text-spotify-green mr-2" />
                          <span className="font-medium capitalize">{meal}:</span>
                          <span className="ml-2">{items}</span>
                        </p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Mess Timings and Entry */}
            <div className="space-y-8">
              <div className="bg-spotify-dark-gray rounded-3xl shadow-xl p-8">
                <h2 className="text-3xl font-bold mb-8 flex items-center text-white">
                  <Clock className="mr-3 text-spotify-green" /> Mess Timings
                </h2>
                <div className="space-y-6">
                  {Object.entries(MESS_TIMINGS).map(([meal, timing]) => (
                    <div key={meal} className="flex items-center justify-between p-5 rounded-2xl hover:bg-[#383838] transition-all duration-300 group">
                      <div>
                        <h3 className="font-semibold capitalize text-xl text-spotify-green mb-1">{meal}</h3>
                        <p className="text-spotify-light-gray group-hover:text-white">
                          {timing.start} - {timing.end}
                        </p>
                      </div>
                      <button
                        onClick={() => addMeal(timing.price, meal as 'breakfast' | 'lunch' | 'dinner')}
                        className="spotify-button"
                      >
                        Add Entry (₹{timing.price})
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;