import React, { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { History, ArrowLeft, Download, Filter } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

interface Payment {
  id: string;
  amount: number;
  status: string;
  payment_method: string;
  transaction_id: string;
  created_at: string;
}

const PaymentHistory = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const { user } = useAuth();

  const statusColors = {
    completed: 'text-spotify-green',
    pending: 'text-yellow-500',
    failed: 'text-red-500'
  };

  useEffect(() => {
    fetchPayments();
  }, [user, filter]);

  const fetchPayments = async () => {
    if (!user) return;

    try {
      let query = supabase
        .from('payments')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (filter !== 'all') {
        query = query.eq('status', filter);
      }

      const { data, error } = await query;
      if (error) throw error;
      setPayments(data || []);
    } catch (error) {
      console.error('Error fetching payments:', error);
    } finally {
      setLoading(false);
    }
  };

  const downloadCSV = () => {
    const headers = ['Date', 'Amount', 'Status', 'Payment Method', 'Transaction ID'];
    const csvData = payments.map(payment => [
      format(new Date(payment.created_at), 'yyyy-MM-dd HH:mm:ss'),
      payment.amount,
      payment.status,
      payment.payment_method,
      payment.transaction_id
    ]);

    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payment-history-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const getTotalAmount = () => {
    return payments
      .filter(p => p.status === 'completed')
      .reduce((sum, payment) => sum + payment.amount, 0);
  };

  return (
    <div className="min-h-screen bg-spotify-black text-white py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link
              to="/payments"
              className="p-2 hover:bg-spotify-dark-gray rounded-full transition-colors"
            >
              <ArrowLeft size={24} className="text-spotify-green" />
            </Link>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <History className="text-spotify-green" />
              Payment History
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="bg-spotify-dark-gray text-white border-0 rounded-xl focus:ring-spotify-green px-4 py-2"
            >
              <option value="all">All Transactions</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
            <button
              onClick={downloadCSV}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-spotify-dark-gray hover:bg-[#383838] transition-colors"
            >
              <Download size={20} />
              Export CSV
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-spotify-dark-gray rounded-xl p-6">
            <h3 className="text-spotify-light-gray mb-2">Total Payments</h3>
            <p className="text-2xl font-bold">₹{getTotalAmount()}</p>
          </div>
          <div className="bg-spotify-dark-gray rounded-xl p-6">
            <h3 className="text-spotify-light-gray mb-2">Total Transactions</h3>
            <p className="text-2xl font-bold">{payments.length}</p>
          </div>
          <div className="bg-spotify-dark-gray rounded-xl p-6">
            <h3 className="text-spotify-light-gray mb-2">Successful</h3>
            <p className="text-2xl font-bold text-spotify-green">
              {payments.filter(p => p.status === 'completed').length}
            </p>
          </div>
          <div className="bg-spotify-dark-gray rounded-xl p-6">
            <h3 className="text-spotify-light-gray mb-2">Failed</h3>
            <p className="text-2xl font-bold text-red-500">
              {payments.filter(p => p.status === 'failed').length}
            </p>
          </div>
        </div>

        <div className="bg-spotify-dark-gray rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#383838]">
                  <th className="text-left p-4 text-spotify-light-gray font-medium">Date</th>
                  <th className="text-left p-4 text-spotify-light-gray font-medium">Amount</th>
                  <th className="text-left p-4 text-spotify-light-gray font-medium">Status</th>
                  <th className="text-left p-4 text-spotify-light-gray font-medium">Payment Method</th>
                  <th className="text-left p-4 text-spotify-light-gray font-medium">Transaction ID</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#383838]">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-spotify-light-gray">
                      Loading transactions...
                    </td>
                  </tr>
                ) : payments.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-spotify-light-gray">
                      No transactions found
                    </td>
                  </tr>
                ) : (
                  payments.map((payment) => (
                    <tr key={payment.id} className="hover:bg-[#383838] transition-colors">
                      <td className="p-4">
                        {format(new Date(payment.created_at), 'MMM d, yyyy h:mm a')}
                      </td>
                      <td className="p-4 font-medium">₹{payment.amount}</td>
                      <td className="p-4">
                        <span className={`capitalize ${statusColors[payment.status as keyof typeof statusColors]}`}>
                          {payment.status}
                        </span>
                      </td>
                      <td className="p-4 capitalize">{payment.payment_method}</td>
                      <td className="p-4 font-mono text-sm text-spotify-light-gray">
                        {payment.transaction_id}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentHistory;